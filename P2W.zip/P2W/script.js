document.addEventListener('DOMContentLoaded', function () {
  const homeBtn = document.getElementById('home-btn');
  const websiteBtn = document.getElementById('website-btn');
  const accountBtn = document.getElementById('account-btn');
  const homeSection = document.getElementById('home');
  const websiteSection = document.getElementById('website');
  const accountSection = document.getElementById('account');
  const signupForm = document.getElementById('signup-form');
  const loginForm = document.getElementById('login-form');
  
  homeBtn.addEventListener('click', function () {
    activateSection(homeSection);
  });

  websiteBtn.addEventListener('click', function () {
    activateSection(websiteSection);
  });

  accountBtn.addEventListener('click', function () {
    activateSection(accountSection);
  });

  signupForm.addEventListener('submit', function (event) {
    event.preventDefault();
    // Handle sign-up form submission
    const username = document.getElementById('signup-username').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    // You can send this data to your server for processing
    console.log('Sign up:', username, email, password);
    // Optionally, you can display a message to the user indicating success or failure
  });

  loginForm.addEventListener('submit', function (event) {
    event.preventDefault();
    // Handle log-in form submission
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    // You can send this data to your server for authentication
    console.log('Log in:', username, password);
    // Optionally, you can redirect the user to another page upon successful login
  });

  function activateSection(section) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(function (s) {
      s.classList.remove('active');
    });
    section.classList.add('active');
  }
});
